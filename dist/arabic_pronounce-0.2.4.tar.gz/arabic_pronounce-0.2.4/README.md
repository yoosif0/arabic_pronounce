
## Arabic Pronounce

This project is based on the workings of 
* Dr. Nawar Halabi https://github.com/nawarhalabi/Arabic-Phonetiser
      * I am almost exaclty using the same code but just removing unneeded stuff and changing the format of the final output.

## Usage
```python
from arabic_pronounce import phonetise

phonetise("كلمةٌ")
>>> ['k l m t u1 n']
```

## Test
python -m pytest